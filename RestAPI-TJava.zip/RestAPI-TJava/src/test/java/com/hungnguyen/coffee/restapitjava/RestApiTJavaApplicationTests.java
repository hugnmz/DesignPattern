package com.hungnguyen.coffee.restapitjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiTJavaApplicationTests {

    @Test
    void contextLoads() {
    }

}
