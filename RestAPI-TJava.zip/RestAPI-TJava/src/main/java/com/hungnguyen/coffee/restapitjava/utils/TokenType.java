package com.hungnguyen.coffee.restapitjava.utils;

public enum TokenType {
    ACCESS_TOKEN,
    REFRESH_TOKEN,
    RESET_TOKEN,;
}
