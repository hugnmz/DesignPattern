package com.hungnguyen.coffee.restapitjava.dto.request;

public class AddressDTO {
}
