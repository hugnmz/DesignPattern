package com.hungnguyen.coffee.restapitjava.utils;

public enum Platform {
    WEB, IOS, ANDROID;
}
