package com.hungnguyen.coffee.restapitjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiTJavaApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestApiTJavaApplication.class, args);
    }

}
